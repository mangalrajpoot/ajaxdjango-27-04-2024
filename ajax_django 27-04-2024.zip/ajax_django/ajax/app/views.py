from django.shortcuts import render
from .models import User

# Create your views here.
def index(request):
    return render(request,'app/index.html')

def data(request):
    query=request.GET['a']
    d=User.objects.filter(name__startswith=query) #select * from User where name like query;
    return render(request,'app/data.html',{'data':d})
